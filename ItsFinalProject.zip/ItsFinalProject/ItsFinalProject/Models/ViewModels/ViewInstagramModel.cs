﻿using System.ComponentModel.DataAnnotations;

namespace ItsFinalProject.Models.ViewModels
{
    public class ViewInstagramModel
    {
        [Key]
        public int Ino { get; set; }
        public IFormFile profilePicture { get; set; }

        [Required]
        public string fullName { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string contact { get; set; }
        public DateTime dob { get; set; }
        public string gender { get; set; }
        public string bio { get; set; }
        public string website { get; set; }
    }
}
