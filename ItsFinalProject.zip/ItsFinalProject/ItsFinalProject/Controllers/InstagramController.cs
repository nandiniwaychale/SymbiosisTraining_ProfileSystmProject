﻿using Microsoft.AspNetCore.Mvc;
using ItsFinalProject.Data;
using ItsFinalProject.Models;
using ItsFinalProject.Models.ViewModels;



namespace ItsFinalProject.Controllers
{
    public class InstagramController : Controller
    {
        public IActionResult Index()
        {
            var data = _context.Insta.ToList();
            return View(data);
        }

        //context and environment
        private readonly InstagramContext _context;
        private readonly IWebHostEnvironment _environment;


        public InstagramController(InstagramContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }
        [HttpGet]
        public IActionResult ViewInstagram()
        {
            return View();
        }
        [HttpPost]
        public IActionResult ViewInstagram(ViewInstagramModel model)
        {
            //check whether the Model is valid or not
            if (ModelState.IsValid)
            {
                var path = _environment.WebRootPath;
                var filePath = "content/image/" + model.profilePicture.FileName;
                var fullPath = Path.Combine(path, filePath);
                UploadImage(model.profilePicture, fullPath);
                var data = new Instagram()
                {
                    profilePicture = filePath,
                    fullName = model.fullName,
                    username = model.username,
                    password = model.password,
                    contact = model.contact,
                    dob = model.dob,
                    gender = model.gender,
                    bio = model.bio,
                    website = model.website,
                };
                _context.Add(data);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }
            else
            {
                return View(model);
            }
        }
        public void UploadImage(IFormFile file, string path)
        {
            FileStream stream = new FileStream(path, FileMode.Create);
            file.CopyTo(stream);
        }
    }
}
